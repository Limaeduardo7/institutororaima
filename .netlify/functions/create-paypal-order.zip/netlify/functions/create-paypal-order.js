var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/@paypal/checkout-server-sdk/lib/core/access_token.js
var require_access_token = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/core/access_token.js"(exports2, module2) {
    "use strict";
    var EXPIRATION_THRESHOLD = 500;
    var AccessToken = class {
      /**
       * @param {object} options - The access token object as it was granted by the token endpoint
       * @param {string} options.access_token - The access token
       * @param {string} options.token_type - The token type
       * @param {number} options.expires_in - The duration of the token in milliseconds
       * @param {string} options.refresh_token - The refresh token if any to refresh the current token
       */
      constructor(options) {
        this._accessToken = options.access_token;
        this._tokenType = options.token_type;
        this._expiresIn = options.expires_in * 1e3;
        this._dateCreated = Date.now();
      }
      /**
       * Get the expiration status of the token
       * @return {boolean} - True if the token is expired otherwise false
       */
      isExpired() {
        return Date.now() > this._dateCreated + this._expiresIn - EXPIRATION_THRESHOLD;
      }
      /**
       * Get the value of an Authorization header with the current access token
       * @return {string} - The Authorization header value
       */
      authorizationString() {
        return `${this._tokenType} ${this._accessToken}`;
      }
    };
    module2.exports = {
      AccessToken
    };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/core/access_token_request.js
var require_access_token_request = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/core/access_token_request.js"(exports2, module2) {
    "use strict";
    var AccessTokenRequest = class {
      /**
       * @param {PayPalEnvironment} environment - The environment for this request (sandbox or live)
       * @param {string} [refreshToken] - An optional refresh token to use refreshing instead of granting
       */
      constructor(environment2, refreshToken) {
        let body = {
          grant_type: "client_credentials"
        };
        if (refreshToken) {
          body = {
            grant_type: "refresh_token",
            refresh_token: refreshToken
          };
        }
        this.path = "/v1/oauth2/token";
        this.body = body;
        this.verb = "POST";
        this.headers = {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization: environment2.authorizationString()
        };
      }
    };
    module2.exports = {
      AccessTokenRequest
    };
  }
});

// node_modules/@paypal/paypalhttp/lib/paypalhttp/environment.js
var require_environment = __commonJS({
  "node_modules/@paypal/paypalhttp/lib/paypalhttp/environment.js"(exports2, module2) {
    "use strict";
    var Environment = class {
      constructor(baseUrl) {
        this.baseUrl = baseUrl;
      }
    };
    module2.exports = { Environment };
  }
});

// node_modules/@paypal/paypalhttp/lib/paypalhttp/encoder.js
var require_encoder = __commonJS({
  "node_modules/@paypal/paypalhttp/lib/paypalhttp/encoder.js"(exports2, module2) {
    "use strict";
    var zlib = require("zlib");
    var Encoder = class {
      constructor(encoders) {
        this._encoders = encoders;
      }
      serializeRequest(request) {
        let contentType = request.headers["content-type"];
        if (!contentType) {
          throw new Error("HttpRequest does not have Content-Type header set");
        }
        let encoder = this._encoder(contentType);
        if (!encoder) {
          throw new Error(`Unable to serialize request with Content-Type ${contentType}. Supported encodings are ${this.supportedEncodings()}`);
        }
        let contentEncoding = request.headers["content-encoding"];
        let encoded = encoder.encode(request);
        if (contentEncoding === "gzip") {
          return zlib.gzipSync(encoded);
        }
        return encoded;
      }
      deserializeResponse(responseBody, headers) {
        let contentType = headers["content-type"];
        if (!contentType) {
          throw new Error("HttpRequest does not have Content-Type header set");
        }
        contentType = contentType.toLowerCase();
        let encoder = this._encoder(contentType);
        if (!encoder) {
          throw new Error(`Unable to deserialize response with Content-Type ${contentType}. Supported decodings are ${this.supportedEncodings()}`);
        }
        return encoder.decode(responseBody);
      }
      supportedEncodings() {
        return "[" + this._encoders.map((e) => e.contentType().toString()).join(", ") + "]";
      }
      _encoder(contentType) {
        for (let i = 0; i < this._encoders.length; i++) {
          let enc = this._encoders[i];
          if (enc.contentType().test(contentType)) {
            return enc;
          }
        }
        return null;
      }
    };
    module2.exports = { Encoder };
  }
});

// node_modules/@paypal/paypalhttp/lib/paypalhttp/serializer/json.js
var require_json = __commonJS({
  "node_modules/@paypal/paypalhttp/lib/paypalhttp/serializer/json.js"(exports2, module2) {
    "use strict";
    var Json = class {
      encode(request) {
        return JSON.stringify(request.body);
      }
      decode(body) {
        return JSON.parse(body);
      }
      contentType() {
        return /^application\/json/;
      }
    };
    module2.exports.Json = Json;
  }
});

// node_modules/@paypal/paypalhttp/lib/paypalhttp/serializer/text.js
var require_text = __commonJS({
  "node_modules/@paypal/paypalhttp/lib/paypalhttp/serializer/text.js"(exports2, module2) {
    "use strict";
    var Text = class {
      encode(request) {
        if (typeof request.body === "string") {
          return request.body;
        }
        return request.body.toString();
      }
      decode(body) {
        if (typeof body === "string") {
          return body;
        }
        return body.toString();
      }
      contentType() {
        return /^text\/.*/;
      }
    };
    module2.exports.Text = Text;
  }
});

// node_modules/@paypal/paypalhttp/lib/paypalhttp/serializer/form_encoded.js
var require_form_encoded = __commonJS({
  "node_modules/@paypal/paypalhttp/lib/paypalhttp/serializer/form_encoded.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var FormEncoded = class {
      contentType() {
        return /^application\/x-www-form-urlencoded/;
      }
      encode(httpRequest) {
        let parts = [];
        for (const key of Object.keys(httpRequest.body)) {
          parts.push(`${key}=${querystring.escape(httpRequest.body[key])}`);
        }
        return parts.join("&");
      }
      decode() {
        throw new Error("FormEncoded does not support deserialization");
      }
    };
    module2.exports.FormEncoded = FormEncoded;
  }
});

// node_modules/@paypal/paypalhttp/lib/paypalhttp/serializer/multipart.js
var require_multipart = __commonJS({
  "node_modules/@paypal/paypalhttp/lib/paypalhttp/serializer/multipart.js"(exports2, module2) {
    "use strict";
    var fs = require("fs");
    var path = require("path");
    var Encoder = require_encoder().Encoder;
    var Json = require_json().Json;
    var Text = require_text().Text;
    var FormEncoded = require_form_encoded().FormEncoded;
    var FormPart = class {
      constructor(value, headers) {
        this.headers = {};
        this.value = value;
        Object.keys(headers).forEach((key) => {
          this.headers[key.toLowerCase().split("-").map((word) => {
            return word[0].toUpperCase() + word.slice(1);
          }).join("-")] = headers[key];
        });
      }
    };
    var Multipart = class _Multipart {
      static get _CRLF() {
        return "\r\n";
      }
      encode(request) {
        let buffers = null;
        let fileBuffers = [];
        let valueBuffers = [];
        let boundary = "boundary" + Date.now();
        request.headers["content-type"] += `; boundary=${boundary}`;
        for (const key of Object.keys(request.body)) {
          let val = request.body[key];
          if (val instanceof fs.ReadStream) {
            fileBuffers.push(this._filePart(key, val, boundary, request));
          } else {
            valueBuffers.push(this._formPart(key, val, boundary, request));
          }
        }
        buffers = valueBuffers.concat(fileBuffers);
        buffers.push(Buffer.from(`--${boundary}--`));
        buffers.push(Buffer.from(_Multipart._CRLF));
        buffers.push(Buffer.from(_Multipart._CRLF));
        return Buffer.concat(buffers);
      }
      formatHeaders(headers) {
        if (headers == null) {
          return headers;
        }
        let formattedHeader = {};
        Object.keys(headers).forEach(function(key) {
          if (key != null) {
            formattedHeader[key.toLowerCase()] = headers[key];
          }
        });
        return formattedHeader;
      }
      decode() {
        throw new Error("Multipart does not support deserialization.");
      }
      contentType() {
        return /^multipart\/.*/;
      }
      _filePart(key, readStream, boundary, request) {
        return Buffer.concat([
          Buffer.from(this._partHeader(key, path.basename(readStream.path), boundary, request)),
          fs.readFileSync(readStream.path),
          Buffer.from(_Multipart._CRLF)
        ]);
      }
      _formPart(key, formPart, boundary, request) {
        let formPartContentType = null;
        let formPartValue = null;
        let contentBuffer = null;
        let encoder = new Encoder([new Json(), new Text(), new FormEncoded()]);
        let formattedHeaders = this.formatHeaders(formPart.headers);
        if (formPart instanceof FormPart) {
          formPartContentType = formattedHeaders["content-type"];
          formPartValue = formPart.value;
        }
        if (formPartContentType) {
          let body = encoder.serializeRequest({
            body: formPartValue,
            headers: formattedHeaders
          });
          contentBuffer = Buffer.from(body + _Multipart._CRLF);
        } else {
          contentBuffer = Buffer.from(formPart + _Multipart._CRLF);
        }
        return Buffer.concat([
          Buffer.from(this._partHeader(key, null, boundary, request)),
          contentBuffer
        ]);
      }
      _partHeader(key, filename, boundary, request) {
        let formPart = request.body[key];
        let part = `--${boundary}`;
        part += _Multipart._CRLF;
        part += `Content-Disposition: form-data; name="${key}"`;
        if (filename) {
          part += `; filename="${filename}"`;
          part += _Multipart._CRLF;
          part += `Content-Type: ${this._filetype(filename)}`;
        }
        if (formPart instanceof FormPart) {
          let partHeaders = formPart.headers;
          if (partHeaders["Content-Type"] === "application/json") {
            part += `; filename="${key}.json"`;
          }
          for (const headerKey of Object.keys(partHeaders)) {
            part += _Multipart._CRLF;
            part += headerKey + ": " + partHeaders[headerKey];
          }
        }
        part += `${_Multipart._CRLF}${_Multipart._CRLF}`;
        return part;
      }
      _filetype(filename) {
        let ext = path.extname(filename);
        if (ext === ".jpeg" || ext === ".jpg") {
          return "image/jpeg";
        } else if (ext === ".png") {
          return "image/png";
        } else if (ext === ".gif") {
          return "image/gif";
        } else if (ext === ".pdf") {
          return "application/pdf";
        }
        return "application/octet-stream";
      }
    };
    module2.exports = {
      Multipart,
      FormPart
    };
  }
});

// node_modules/@paypal/paypalhttp/lib/paypalhttp/http_client.js
var require_http_client = __commonJS({
  "node_modules/@paypal/paypalhttp/lib/paypalhttp/http_client.js"(exports2, module2) {
    "use strict";
    var http = require("http");
    var https = require("https");
    var Buffer2 = require("buffer").Buffer;
    var url = require("url");
    var Encoder = require_encoder().Encoder;
    var zlib = require("zlib");
    var Json = require_json().Json;
    var Text = require_text().Text;
    var Multipart = require_multipart().Multipart;
    var FormEncoded = require_form_encoded().FormEncoded;
    var THIRTY_SECONDS = 10 * 3e3;
    var HttpError = class extends Error {
      constructor(response) {
        super();
        this.message = response.message || response.text || "An unknown error occured.";
        this.statusCode = response.statusCode;
        this.headers = response.headers;
        this._originalError = response;
      }
    };
    var HttpClient = class {
      constructor(environment2) {
        this.environment = environment2;
        this._injectors = [];
        this.encoder = new Encoder([new Json(), new Text(), new Multipart(), new FormEncoded()]);
      }
      getUserAgent() {
        return "PayPalHttp-Node HTTP/1.1";
      }
      getTimeout() {
        return THIRTY_SECONDS;
      }
      addInjector(injector) {
        if (typeof injector !== "function" || injector.length !== 1) {
          throw new Error("injector must be a function that takes one argument");
        }
        this._injectors.push(injector);
      }
      formatHeaders(headers) {
        let formattedHeader = {};
        Object.keys(headers).forEach(function(key) {
          if (key != null) {
            if (key.toLowerCase() === "content-type") {
              formattedHeader[key.toLowerCase()] = headers[key].toLowerCase();
            } else {
              formattedHeader[key.toLowerCase()] = headers[key];
            }
          }
        });
        return formattedHeader;
      }
      mapHeader(rawHeaders, formattedHeaders) {
        Object.keys(rawHeaders).forEach(function(key) {
          if (key != null) {
            let lCase = key.toLowerCase();
            if (formattedHeaders[lCase] != null) {
              rawHeaders[key] = formattedHeaders[lCase];
            }
          }
        });
        return rawHeaders;
      }
      execute(req) {
        let request = Object.assign({}, req);
        if (!request.headers) {
          request.headers = {};
        }
        let injectorPromises = this._injectors.map(function(injector) {
          return injector(request);
        });
        let requestBody, requestAborted;
        let client2 = this.environment.baseUrl.startsWith("https") ? https : http;
        let parsedUrl = url.parse(this.environment.baseUrl);
        request.host = parsedUrl.hostname;
        request.port = parsedUrl.port;
        let formattedHeaders = this.formatHeaders(request.headers);
        if (!formattedHeaders["user-agent"] || formattedHeaders["user-agent"] === "Node") {
          request.headers["User-Agent"] = this.getUserAgent();
        }
        if (request.body) {
          let rawHeaders = request.headers;
          request.headers = formattedHeaders;
          requestBody = this.encoder.serializeRequest(request);
          request.headers = this.mapHeader(rawHeaders, formattedHeaders);
          request.headers["Content-Length"] = Buffer2.byteLength(requestBody).toString();
        }
        if (request.verb) {
          request.method = request.verb;
        }
        return new Promise((resolve, reject) => {
          return Promise.all(injectorPromises).then(() => {
            let theRequest = client2.request(request, (response) => {
              let buffers = [];
              response.on("data", (responseBody) => {
                buffers.push(responseBody);
              });
              response.on("end", () => {
                formattedHeaders = this.formatHeaders(response.headers);
                let contentEncoding = formattedHeaders["content-encoding"];
                let body = Buffer2.concat(buffers);
                if (contentEncoding === "gzip") {
                  body = zlib.gunzipSync(body);
                }
                body = body.toString("utf8");
                if (response.statusCode >= 200 && response.statusCode <= 299) {
                  resolve(this._parseResponse(body, response, formattedHeaders));
                } else {
                  reject(new HttpError({
                    text: body,
                    statusCode: response.statusCode,
                    headers: response.headers
                  }));
                }
              });
              response.on("error", reject);
            });
            function timeoutHandler() {
              theRequest.abort();
              requestAborted = true;
              reject(new Error("Request timed out"));
            }
            theRequest.setTimeout(this.getTimeout(), timeoutHandler);
            let requestSocket = null;
            theRequest.on("socket", (socket) => {
              requestSocket = socket;
            });
            theRequest.on("error", (error) => {
              if (requestAborted) {
                return;
              }
              requestSocket.removeListener("timeout", timeoutHandler);
              reject(error);
            });
            if (requestBody) {
              theRequest.write(requestBody);
            }
            theRequest.end();
          }).catch(reject);
        });
      }
      _parseResponse(body, response, formattedHeaders) {
        var data = {
          statusCode: response.statusCode,
          headers: response.headers
        };
        if (body) {
          data.result = this.encoder.deserializeResponse(body, formattedHeaders);
        }
        return data;
      }
    };
    module2.exports = { HttpClient };
  }
});

// node_modules/@paypal/paypalhttp/lib/paypalhttp.js
var require_paypalhttp = __commonJS({
  "node_modules/@paypal/paypalhttp/lib/paypalhttp.js"(exports2, module2) {
    "use strict";
    var Environment = require_environment().Environment;
    var HttpClient = require_http_client().HttpClient;
    var Encoder = require_encoder().Encoder;
    var FormPart = require_multipart().FormPart;
    module2.exports = {
      Environment,
      HttpClient,
      Encoder,
      FormPart
    };
  }
});

// node_modules/@paypal/paypalhttp/index.js
var require_paypalhttp2 = __commonJS({
  "node_modules/@paypal/paypalhttp/index.js"(exports2, module2) {
    "use strict";
    module2.exports = require_paypalhttp();
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/core/paypal_environment.js
var require_paypal_environment = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/core/paypal_environment.js"(exports2, module2) {
    "use strict";
    var paypalhttp = require_paypalhttp2();
    var SANDBOX = "https://api.sandbox.paypal.com";
    var LIVE = "https://api.paypal.com";
    var SANDBOX_WEB_URL = "https://www.sandbox.paypal.com";
    var LIVE_WEB_URL = "https://www.paypal.com";
    var PayPalEnvironment = class extends paypalhttp.Environment {
      /**
       * @param {string} clientId - The client id for this environment
       * @param {string} clientSecret - The client secret
       * @param {string} baseUrl - The base url to execute requests
       * @param {string} webUrl - The web url to authorize user's consent
       */
      constructor(clientId2, clientSecret2, baseUrl, webUrl) {
        super(baseUrl);
        this.clientId = clientId2;
        this.clientSecret = clientSecret2;
        this.webUrl = webUrl;
      }
      /**
       * Authorization header string for basic authentication with the current client id and secret
       * @return {string} - The authorization header value
       */
      authorizationString() {
        let encoded = new Buffer(`${this.clientId}:${this.clientSecret}`).toString("base64");
        return `Basic ${encoded}`;
      }
    };
    var SandboxEnvironment = class extends PayPalEnvironment {
      constructor(clientId2, clientSecret2) {
        super(clientId2, clientSecret2, SANDBOX, SANDBOX_WEB_URL);
      }
    };
    var LiveEnvironment = class extends PayPalEnvironment {
      constructor(clientId2, clientSecret2) {
        super(clientId2, clientSecret2, LIVE, LIVE_WEB_URL);
      }
    };
    module2.exports = {
      PayPalEnvironment,
      LiveEnvironment,
      SandboxEnvironment
    };
  }
});

// node_modules/@paypal/checkout-server-sdk/package.json
var require_package = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/package.json"(exports2, module2) {
    module2.exports = {
      name: "@paypal/checkout-server-sdk",
      version: "1.0.3",
      description: "NodeJS SDK for PayPal Checkout APIs",
      keywords: [],
      homepage: "https://github.com/paypal/Checkout-NodeJS-SDK#readme",
      author: "dl-paypal-checkout-api@paypal.com (https://developer.paypal.com/)",
      main: "index",
      directories: {
        lib: "lib"
      },
      repository: {
        type: "git",
        url: "https://github.com/paypal/Checkout-NodeJS-SDK.git"
      },
      engines: {
        node: ">=8"
      },
      dependencies: {
        "@paypal/paypalhttp": "^1.0.1"
      },
      devDependencies: {
        btoa: "^1.2.1",
        chai: "^4.1.2",
        "dirty-chai": "^2.0.1",
        eslint: "^2.7.0",
        "eslint-config-braintree": "^1.0.0",
        mocha: "^5.2.0",
        prompt: "^1.0.0",
        nock: "^9.6.1",
        sinon: "^2.3.2"
      },
      license: "SEE LICENSE IN https://github.com/paypal/Checkout-NodeJS-SDK/blob/master/LICENSE",
      scripts: {
        "test:integration": "mocha spec --recursive",
        test: "npm run test:integration",
        "test:orders": "mocha spec/orders --recursive --timeout 60000"
      },
      bugs: {
        url: "https://github.com/paypal/Checkout-NodeJS-SDK/issues"
      }
    };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/core/token_cache.js
var require_token_cache = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/core/token_cache.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events").EventEmitter;
    var _cacheMap = {};
    var TokenCache = class _TokenCache {
      static cacheForEnvironment(environment2, refreshToken) {
        let key = environment2.clientId;
        if (refreshToken) {
          key += `_${refreshToken}`;
        }
        if (!_cacheMap[key]) {
          _cacheMap[key] = new _TokenCache();
        }
        return _cacheMap[key];
      }
      constructor() {
        this._token = null;
        this._locked = false;
        this._requests = [];
        this._emitter = new EventEmitter();
        this._emitter.setMaxListeners(0);
      }
      /**
       * Gets the current token for the client
       * @return {AccessToken|null} - The current token or null if there is none
       */
      getToken() {
        return this._token;
      }
      /**
       * Sets the token for the current client also setting its status to absent or valid if the token exist or not
       * @param {AccessToken|null} token - The current token for the client or null to remove it
       * @return {void}
       */
      setToken(token) {
        this._token = token;
      }
      lock() {
        this._locked = true;
      }
      unlock() {
        this._locked = false;
      }
      isLocked() {
        return this._locked;
      }
      isValid() {
        return this.isPresent() && !this._token.isExpired();
      }
      isPresent() {
        return Boolean(this._token);
      }
      /**
       * Add a request to the queue and wait for the notify method to signal error or completion
       * @param {Object} request - The request to be queued
       * @return {Promise} - A promise that will resolve or rejects when the notify method is called
       * */
      wait(request) {
        this._requests.push(request);
        return new Promise((resolve, reject) => {
          const completeHandler = (req) => {
            if (request === req) {
              this._emitter.removeListener("complete", completeHandler);
              resolve(request);
            }
          };
          const failHandler = (err) => {
            this._emitter.removeListener("fail", failHandler);
            reject(err);
          };
          this._emitter.on("complete", completeHandler);
          this._emitter.on("fail", failHandler);
        });
      }
      /**
       * Flush the request queue resolving every call in the order they were added or rejects all calls if an error is provided
       * @param {Array} [err] - An optional error that rejects all requests instead of resolving them
       * @return {void} - void
       */
      notify(err) {
        if (err) {
          this._emitter.emit("fail", err);
        } else {
          this._requests.forEach((request) => this._emitter.emit("complete", request));
        }
        this._requests = [];
        this._emitter.removeAllListeners();
      }
    };
    module2.exports = { TokenCache };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/core/paypal_http_client.js
var require_paypal_http_client = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/core/paypal_http_client.js"(exports2, module2) {
    "use strict";
    var paypalhttp = require_paypalhttp2();
    var AccessToken = require_access_token().AccessToken;
    var AccessTokenRequest = require_access_token_request().AccessTokenRequest;
    var sdkVersion = require_package().version;
    var TokenCache = require_token_cache().TokenCache;
    var PayPalHttpClient = class extends paypalhttp.HttpClient {
      /**
       * @param {PayPalEnvironment} environment - The environment for this client
       * @param {string} refreshToken - The refreshToken to be used to generate the access Token.
       */
      constructor(environment2, refreshToken) {
        super(environment2);
        this._cache = TokenCache.cacheForEnvironment(environment2, refreshToken);
        this.refreshToken = refreshToken;
        this.addInjector(authInjector.bind(this));
        this.addInjector(function(req) {
          req.headers["Accept-Encoding"] = "gzip";
          req.headers["sdk_name"] = "Checkout SDK";
          req.headers["sdk_version"] = "1.0.3";
          req.headers["sdk_tech_stack"] = "NodeJS " + process.version;
          req.headers["api_integration_type"] = "PAYPALSDK";
        });
      }
      /**
       * Returns the user agent for this client implementation
       * @override
       * @return {string} - The user agent string
       */
      getUserAgent() {
        return "PayPalSDK/PayPal-node-SDK " + sdkVersion + " (node " + process.version + "-" + process.arch + "-" + process.platform + "; OpenSSL " + process.versions.openssl + ")";
      }
      execute(request) {
        return super.execute(request).catch((err) => {
          if (err.statusCode === 401) {
            return this._retryRequest(request);
          }
          return Promise.reject(err);
        });
      }
      _retryRequest(request) {
        const promise = this._cache.wait(request).then(() => {
          this._setAuthHeader(request);
          return super.execute(request);
        });
        if (this._cache.isLocked()) {
          return promise;
        }
        return Promise.race([this.fetchAccessToken(), promise]).then(() => promise);
      }
      fetchAccessToken() {
        this._cache.lock();
        return super.execute(new AccessTokenRequest(this.environment, this.refreshToken)).then((resp) => {
          const token = new AccessToken(resp.result);
          this._cache.setToken(token);
          this._cache.notify();
          this._cache.unlock();
          return token;
        }).catch((err) => {
          this._cache.setToken(null);
          this._cache.notify(err);
          this._cache.unlock();
          return Promise.reject(err);
        });
      }
      /**
       * Sets the Authorization header for this request based on the client token
       * @param {Object} request - The request to modify
       * @private
       * @return {void}
       */
      _setAuthHeader(request) {
        const token = this._cache.getToken();
        request.headers = request.headers || {};
        request.headers.Authorization = token.authorizationString();
      }
    };
    function authInjector(request) {
      if (request.headers.Authorization) {
        return;
      }
      if (this._cache.isValid()) {
        this._setAuthHeader(request);
      } else if (this._cache.isLocked()) {
        return this._cache.wait(request).then(() => this._setAuthHeader(request));
      } else if (!this._cache.isValid()) {
        return Promise.all([
          this._cache.wait(request),
          this.fetchAccessToken()
        ]).then(() => this._setAuthHeader(request));
      }
    }
    module2.exports = {
      PayPalHttpClient
    };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/core/refresh_token_request.js
var require_refresh_token_request = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/core/refresh_token_request.js"(exports2, module2) {
    "use strict";
    var RefreshTokenRequest = class {
      /**
       * @param {PayPalEnvironment} environment - The environment for this request (sandbox or live)
       * @param {string} code - The authorization code provided at the end of the user consent OAuth flow.
       */
      constructor(environment2, code) {
        let body = {
          grant_type: "authorization_code",
          code
        };
        this.headers = {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization: environment2.authorizationString()
        };
        this.path = "/v1/identity/openidconnect/tokenservice";
        this.body = body;
        this.verb = "POST";
      }
    };
    module2.exports = {
      RefreshTokenRequest
    };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/core/lib.js
var require_lib = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/core/lib.js"(exports2, module2) {
    "use strict";
    module2.exports = {
      AccessToken: require_access_token().AccessToken,
      AccessTokenRequest: require_access_token_request().AccessTokenRequest,
      PayPalEnvironment: require_paypal_environment().PayPalEnvironment,
      LiveEnvironment: require_paypal_environment().LiveEnvironment,
      SandboxEnvironment: require_paypal_environment().SandboxEnvironment,
      PayPalHttpClient: require_paypal_http_client().PayPalHttpClient,
      RefreshTokenRequest: require_refresh_token_request().RefreshTokenRequest,
      TokenCache: require_token_cache().TokenCache
    };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/orders/ordersAuthorizeRequest.js
var require_ordersAuthorizeRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/orders/ordersAuthorizeRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var OrdersAuthorizeRequest = class {
      constructor(orderId) {
        this.path = "/v2/checkout/orders/{order_id}/authorize?";
        this.path = this.path.replace("{order_id}", querystring.escape(orderId));
        this.verb = "POST";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
      payPalClientMetadataId(payPalClientMetadataId) {
        this.headers["PayPal-Client-Metadata-Id"] = payPalClientMetadataId;
        return this;
      }
      payPalRequestId(payPalRequestId) {
        this.headers["PayPal-Request-Id"] = payPalRequestId;
        return this;
      }
      prefer(prefer) {
        this.headers["Prefer"] = prefer;
        return this;
      }
      requestBody(orderActionRequest) {
        this.body = orderActionRequest;
        return this;
      }
    };
    module2.exports = { OrdersAuthorizeRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/orders/ordersCaptureRequest.js
var require_ordersCaptureRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/orders/ordersCaptureRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var OrdersCaptureRequest = class {
      constructor(orderId) {
        this.path = "/v2/checkout/orders/{order_id}/capture?";
        this.path = this.path.replace("{order_id}", querystring.escape(orderId));
        this.verb = "POST";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
      payPalClientMetadataId(payPalClientMetadataId) {
        this.headers["PayPal-Client-Metadata-Id"] = payPalClientMetadataId;
        return this;
      }
      payPalRequestId(payPalRequestId) {
        this.headers["PayPal-Request-Id"] = payPalRequestId;
        return this;
      }
      prefer(prefer) {
        this.headers["Prefer"] = prefer;
        return this;
      }
      requestBody(orderActionRequest) {
        this.body = orderActionRequest;
        return this;
      }
    };
    module2.exports = { OrdersCaptureRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/orders/ordersCreateRequest.js
var require_ordersCreateRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/orders/ordersCreateRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var OrdersCreateRequest = class {
      constructor() {
        this.path = "/v2/checkout/orders?";
        this.verb = "POST";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
      payPalPartnerAttributionId(payPalPartnerAttributionId) {
        this.headers["PayPal-Partner-Attribution-Id"] = payPalPartnerAttributionId;
        return this;
      }
      prefer(prefer) {
        this.headers["Prefer"] = prefer;
        return this;
      }
      requestBody(order) {
        this.body = order;
        return this;
      }
    };
    module2.exports = { OrdersCreateRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/orders/ordersGetRequest.js
var require_ordersGetRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/orders/ordersGetRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var OrdersGetRequest = class {
      constructor(orderId) {
        this.path = "/v2/checkout/orders/{order_id}?";
        this.path = this.path.replace("{order_id}", querystring.escape(orderId));
        this.verb = "GET";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
    };
    module2.exports = { OrdersGetRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/orders/ordersPatchRequest.js
var require_ordersPatchRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/orders/ordersPatchRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var OrdersPatchRequest = class {
      constructor(orderId) {
        this.path = "/v2/checkout/orders/{order_id}?";
        this.path = this.path.replace("{order_id}", querystring.escape(orderId));
        this.verb = "PATCH";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
      requestBody(patchRequest) {
        this.body = patchRequest;
        return this;
      }
    };
    module2.exports = { OrdersPatchRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/orders/ordersValidateRequest.js
var require_ordersValidateRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/orders/ordersValidateRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var OrdersValidateRequest = class {
      constructor(orderId) {
        this.path = "/v2/checkout/orders/{order_id}/validate-payment-method?";
        this.path = this.path.replace("{order_id}", querystring.escape(orderId));
        this.verb = "POST";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
      payPalClientMetadataId(payPalClientMetadataId) {
        this.headers["PayPal-Client-Metadata-Id"] = payPalClientMetadataId;
        return this;
      }
      requestBody(orderActionRequest) {
        this.body = orderActionRequest;
        return this;
      }
    };
    module2.exports = { OrdersValidateRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/orders/lib.js
var require_lib2 = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/orders/lib.js"(exports2, module2) {
    "use strict";
    module2.exports = {
      OrdersAuthorizeRequest: require_ordersAuthorizeRequest().OrdersAuthorizeRequest,
      OrdersCaptureRequest: require_ordersCaptureRequest().OrdersCaptureRequest,
      OrdersCreateRequest: require_ordersCreateRequest().OrdersCreateRequest,
      OrdersGetRequest: require_ordersGetRequest().OrdersGetRequest,
      OrdersPatchRequest: require_ordersPatchRequest().OrdersPatchRequest,
      OrdersValidateRequest: require_ordersValidateRequest().OrdersValidateRequest
    };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/payments/authorizationsCaptureRequest.js
var require_authorizationsCaptureRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/payments/authorizationsCaptureRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var AuthorizationsCaptureRequest = class {
      constructor(authorizationId) {
        this.path = "/v2/payments/authorizations/{authorization_id}/capture?";
        this.path = this.path.replace("{authorization_id}", querystring.escape(authorizationId));
        this.verb = "POST";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
      payPalRequestId(payPalRequestId) {
        this.headers["PayPal-Request-Id"] = payPalRequestId;
        return this;
      }
      prefer(prefer) {
        this.headers["Prefer"] = prefer;
        return this;
      }
      requestBody(capture) {
        this.body = capture;
        return this;
      }
    };
    module2.exports = { AuthorizationsCaptureRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/payments/authorizationsGetRequest.js
var require_authorizationsGetRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/payments/authorizationsGetRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var AuthorizationsGetRequest = class {
      constructor(authorizationId) {
        this.path = "/v2/payments/authorizations/{authorization_id}?";
        this.path = this.path.replace("{authorization_id}", querystring.escape(authorizationId));
        this.verb = "GET";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
    };
    module2.exports = { AuthorizationsGetRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/payments/authorizationsReauthorizeRequest.js
var require_authorizationsReauthorizeRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/payments/authorizationsReauthorizeRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var AuthorizationsReauthorizeRequest = class {
      constructor(authorizationId) {
        this.path = "/v2/payments/authorizations/{authorization_id}/reauthorize?";
        this.path = this.path.replace("{authorization_id}", querystring.escape(authorizationId));
        this.verb = "POST";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
      payPalRequestId(payPalRequestId) {
        this.headers["PayPal-Request-Id"] = payPalRequestId;
        return this;
      }
      prefer(prefer) {
        this.headers["Prefer"] = prefer;
        return this;
      }
      requestBody(reauthorizeRequest) {
        this.body = reauthorizeRequest;
        return this;
      }
    };
    module2.exports = { AuthorizationsReauthorizeRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/payments/authorizationsVoidRequest.js
var require_authorizationsVoidRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/payments/authorizationsVoidRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var AuthorizationsVoidRequest = class {
      constructor(authorizationId) {
        this.path = "/v2/payments/authorizations/{authorization_id}/void?";
        this.path = this.path.replace("{authorization_id}", querystring.escape(authorizationId));
        this.verb = "POST";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
    };
    module2.exports = { AuthorizationsVoidRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/payments/capturesGetRequest.js
var require_capturesGetRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/payments/capturesGetRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var CapturesGetRequest = class {
      constructor(captureId) {
        this.path = "/v2/payments/captures/{capture_id}?";
        this.path = this.path.replace("{capture_id}", querystring.escape(captureId));
        this.verb = "GET";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
    };
    module2.exports = { CapturesGetRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/payments/capturesRefundRequest.js
var require_capturesRefundRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/payments/capturesRefundRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var CapturesRefundRequest = class {
      constructor(captureId) {
        this.path = "/v2/payments/captures/{capture_id}/refund?";
        this.path = this.path.replace("{capture_id}", querystring.escape(captureId));
        this.verb = "POST";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
      payPalRequestId(payPalRequestId) {
        this.headers["PayPal-Request-Id"] = payPalRequestId;
        return this;
      }
      prefer(prefer) {
        this.headers["Prefer"] = prefer;
        return this;
      }
      requestBody(refundRequest) {
        this.body = refundRequest;
        return this;
      }
    };
    module2.exports = { CapturesRefundRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/payments/refundsGetRequest.js
var require_refundsGetRequest = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/payments/refundsGetRequest.js"(exports2, module2) {
    "use strict";
    var querystring = require("querystring");
    var RefundsGetRequest = class {
      constructor(refundId) {
        this.path = "/v2/payments/refunds/{refund_id}?";
        this.path = this.path.replace("{refund_id}", querystring.escape(refundId));
        this.verb = "GET";
        this.body = null;
        this.headers = {
          "Content-Type": "application/json"
        };
      }
    };
    module2.exports = { RefundsGetRequest };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/payments/lib.js
var require_lib3 = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/payments/lib.js"(exports2, module2) {
    "use strict";
    module2.exports = {
      AuthorizationsCaptureRequest: require_authorizationsCaptureRequest().AuthorizationsCaptureRequest,
      AuthorizationsGetRequest: require_authorizationsGetRequest().AuthorizationsGetRequest,
      AuthorizationsReauthorizeRequest: require_authorizationsReauthorizeRequest().AuthorizationsReauthorizeRequest,
      AuthorizationsVoidRequest: require_authorizationsVoidRequest().AuthorizationsVoidRequest,
      CapturesGetRequest: require_capturesGetRequest().CapturesGetRequest,
      CapturesRefundRequest: require_capturesRefundRequest().CapturesRefundRequest,
      RefundsGetRequest: require_refundsGetRequest().RefundsGetRequest
    };
  }
});

// node_modules/@paypal/checkout-server-sdk/lib/lib.js
var require_lib4 = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/lib/lib.js"(exports2, module2) {
    "use strict";
    module2.exports = {
      core: require_lib(),
      orders: require_lib2(),
      payments: require_lib3()
    };
  }
});

// node_modules/@paypal/checkout-server-sdk/index.js
var require_checkout_server_sdk = __commonJS({
  "node_modules/@paypal/checkout-server-sdk/index.js"(exports2, module2) {
    "use strict";
    module2.exports = require_lib4();
  }
});

// netlify/functions/create-paypal-order.ts
var create_paypal_order_exports = {};
__export(create_paypal_order_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_paypal_order_exports);
var import_checkout_server_sdk = __toESM(require_checkout_server_sdk(), 1);
var clientId = process.env.VITE_PAYPAL_CLIENT_ID || "";
var clientSecret = process.env.PAYPAL_CLIENT_SECRET || "";
var environment = new import_checkout_server_sdk.default.core.LiveEnvironment(clientId, clientSecret);
var client = new import_checkout_server_sdk.default.core.PayPalHttpClient(environment);
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ message: "Method Not Allowed" })
    };
  }
  try {
    if (!clientId || !clientSecret) {
      throw new Error("Credenciais do PayPal n\xE3o configuradas");
    }
    const body = JSON.parse(event.body || "{}");
    const {
      amount,
      currency = "USD",
      donor_name,
      donor_email,
      donor_phone,
      message,
      return_url,
      cancel_url
    } = body;
    if (!amount || amount <= 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: "Valor inv\xE1lido" })
      };
    }
    const request = new import_checkout_server_sdk.default.orders.OrdersCreateRequest();
    request.prefer("return=representation");
    request.requestBody({
      intent: "CAPTURE",
      purchase_units: [
        {
          description: `Doa\xE7\xE3o - Instituto Esta\xE7\xE3o${donor_name ? ` - ${donor_name}` : ""}`,
          amount: {
            currency_code: currency,
            value: amount.toFixed(2)
          },
          custom_id: donor_email || void 0
        }
      ],
      application_context: {
        brand_name: "Instituto Esta\xE7\xE3o",
        landing_page: "BILLING",
        user_action: "PAY_NOW",
        return_url: return_url || `${process.env.URL}/doacoes?status=success&payment=paypal`,
        cancel_url: cancel_url || `${process.env.URL}/doacoes?status=cancelled&payment=paypal`
      },
      payer: donor_email ? {
        email_address: donor_email,
        name: donor_name ? {
          given_name: donor_name.split(" ")[0] || "",
          surname: donor_name.split(" ").slice(1).join(" ") || ""
        } : void 0
      } : void 0
    });
    const order = await client.execute(request);
    const approvalUrl = order.result.links?.find(
      (link) => link.rel === "approve"
    )?.href;
    if (!approvalUrl) {
      throw new Error("URL de aprova\xE7\xE3o n\xE3o encontrada na resposta do PayPal");
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        orderId: order.result.id,
        approvalUrl,
        status: order.result.status
      })
    };
  } catch (error) {
    console.error("Erro ao criar ordem PayPal:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        message: "Erro ao criar ordem de pagamento",
        error: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
