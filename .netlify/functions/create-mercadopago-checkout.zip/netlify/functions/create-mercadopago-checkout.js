var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/create-mercadopago-checkout.ts
var create_mercadopago_checkout_exports = {};
__export(create_mercadopago_checkout_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_mercadopago_checkout_exports);
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const accessToken = process.env.MERCADOPAGO_ACCESS_TOKEN || process.env.VITE_MERCADOPAGO_ACCESS_TOKEN;
    if (!accessToken) {
      console.error("MERCADOPAGO_ACCESS_TOKEN not configured");
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          error: "Mercado Pago not configured",
          message: "Sistema de pagamento n\xE3o est\xE1 configurado corretamente."
        })
      };
    }
    if (!accessToken.startsWith("APP_USR-") && !accessToken.startsWith("TEST-")) {
      console.error("Invalid Mercado Pago access token format");
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          error: "Invalid Mercado Pago configuration",
          message: "Configura\xE7\xE3o do sistema de pagamento \xE9 inv\xE1lida."
        })
      };
    }
    const {
      amount,
      donor_name,
      donor_email,
      donor_phone,
      payment_method
    } = JSON.parse(event.body || "{}");
    if (!amount || amount <= 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Valor inv\xE1lido" })
      };
    }
    const origin = event.headers.origin || event.headers.referer?.replace(/\/$/, "") || "https://institutoeestacao.org.br";
    const response = await fetch("https://api.mercadopago.com/checkout/preferences", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${accessToken}`
      },
      body: JSON.stringify({
        items: [
          {
            title: "Doa\xE7\xE3o - Instituto Esta\xE7\xE3o",
            description: "Contribui\xE7\xE3o para as a\xE7\xF5es sociais do Instituto Esta\xE7\xE3o em Roraima",
            quantity: 1,
            unit_price: Number(amount),
            currency_id: "BRL"
          }
        ],
        payer: {
          name: donor_name || "Doador An\xF4nimo",
          email: donor_email || "doador@institutoeestacao.org.br",
          phone: {
            area_code: donor_phone?.substring(0, 2) || "95",
            number: donor_phone?.substring(2) || "999999999"
          }
        },
        back_urls: {
          success: `${origin}/doacoes?status=success`,
          failure: `${origin}/doacoes?status=failure`,
          pending: `${origin}/doacoes?status=pending`
        },
        auto_return: "approved",
        payment_methods: {
          excluded_payment_types: [],
          installments: 12
        },
        statement_descriptor: "Instituto Estacao",
        external_reference: `DONATION-${Date.now()}`
      })
    });
    if (!response.ok) {
      const errorData = await response.json();
      console.error("Mercado Pago API Error:", errorData);
      return {
        statusCode: response.status,
        headers,
        body: JSON.stringify({
          error: "Erro ao criar prefer\xEAncia de pagamento",
          details: errorData
        })
      };
    }
    const preference = await response.json();
    const isProduction = !accessToken.includes("TEST");
    const checkoutUrl = isProduction ? preference.init_point : preference.sandbox_init_point;
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        preferenceId: preference.id,
        checkoutUrl,
        sandboxUrl: preference.sandbox_init_point,
        productionUrl: preference.init_point
      })
    };
  } catch (error) {
    console.error("Mercado Pago checkout error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Failed to create payment preference",
        message: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
