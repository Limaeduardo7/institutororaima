var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/create-pagarme-checkout.ts
var create_pagarme_checkout_exports = {};
__export(create_pagarme_checkout_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_pagarme_checkout_exports);
var encryptionKey = process.env.PAGARME_PUBLIC_KEY || "";
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod === "GET") {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        encryptionKey: encryptionKey || "",
        message: encryptionKey ? "OK" : "Chave n\xE3o configurada - use process-pagarme-payment diretamente"
      })
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ message: "Method Not Allowed" })
    };
  }
  try {
    if (!encryptionKey) {
      throw new Error("Credenciais do Pagar.me n\xE3o configuradas (PAGARME_PUBLIC_KEY)");
    }
    const body = JSON.parse(event.body || "{}");
    const {
      amount,
      donor_name,
      donor_email,
      donor_phone,
      payment_method,
      message
    } = body;
    if (!amount || amount <= 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: "Valor inv\xE1lido" })
      };
    }
    if (!donor_email) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: "Email \xE9 obrigat\xF3rio" })
      };
    }
    const amountInCents = Math.round(amount * 100);
    const checkoutData = {
      amount: amountInCents,
      createToken: "true",
      paymentMethods: payment_method === "credit_card" ? "credit_card" : payment_method,
      customerData: "false",
      customer: {
        name: donor_name || "Doador An\xF4nimo",
        email: donor_email,
        documentNumber: "00000000000",
        phone: donor_phone ? `+55${donor_phone.replace(/\D/g, "")}` : ""
      },
      metadata: {
        donor_name: donor_name || "An\xF4nimo",
        donor_phone: donor_phone || "",
        message: message || ""
      }
    };
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        checkoutUrl: `${process.env.URL}/doacoes?status=success&payment=pagarme`,
        transactionId: `temp_${Date.now()}`,
        status: "pending",
        checkoutData,
        encryptionKey
      })
    };
  } catch (error) {
    console.error("Erro ao criar checkout Pagar.me:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        message: "Erro ao criar checkout",
        error: error.message || "Erro desconhecido"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
