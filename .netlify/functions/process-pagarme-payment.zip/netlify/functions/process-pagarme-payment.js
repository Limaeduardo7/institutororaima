var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/process-pagarme-payment.ts
var process_pagarme_payment_exports = {};
__export(process_pagarme_payment_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(process_pagarme_payment_exports);
var accessToken = "acs_666666c500ac43dbadb8d89f3ecc6d253fcf9b084a68a6cb2ec691bdbbf5";
var accountId = "acc_nmoNbEeIAI3qbW9K";
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ message: "Method Not Allowed" })
    };
  }
  try {
    if (!accessToken) {
      console.error("Access Token n\xE3o configurado");
      throw new Error("Credenciais do Pagar.me n\xE3o configuradas");
    }
    const body = JSON.parse(event.body || "{}");
    const {
      amount,
      donor_name,
      donor_email,
      donor_phone,
      payment_method,
      card_hash,
      card_holder_cpf
    } = body;
    console.log("Processando pagamento:", { amount, payment_method, donor_email });
    if (!amount || amount <= 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: "Valor inv\xE1lido" })
      };
    }
    if (!donor_email) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: "Email \xE9 obrigat\xF3rio" })
      };
    }
    const amountInCents = Math.round(amount * 100);
    const phoneClean = donor_phone?.replace(/\D/g, "") || "";
    const areaCode = phoneClean.slice(0, 2) || "95";
    const phoneNumber = phoneClean.slice(2) || "00000000";
    const transactionData = {
      closed: true,
      customer: {
        name: donor_name || "Doador An\xF4nimo",
        email: donor_email,
        type: "individual",
        document: card_holder_cpf || "00000000000",
        document_type: "CPF",
        address: {
          line_1: "1, Rua Principal, Centro",
          line_2: "Complemento",
          zip_code: "69300000",
          city: "Boa Vista",
          state: "RR",
          country: "BR"
        },
        phones: {
          home_phone: {
            country_code: "55",
            area_code: areaCode,
            number: phoneNumber
          },
          mobile_phone: {
            country_code: "55",
            area_code: areaCode,
            number: phoneNumber
          }
        }
      },
      items: [
        {
          amount: amountInCents,
          description: "Doa\xE7\xE3o - Instituto Esta\xE7\xE3o",
          quantity: 1,
          code: `DOA${Date.now()}`
        }
      ],
      metadata: {
        donor_name: donor_name || "An\xF4nimo",
        donor_phone: donor_phone || ""
      }
    };
    if (payment_method === "credit_card" && card_hash) {
      transactionData.payments = [
        {
          payment_method: "credit_card",
          credit_card: {
            operation_type: "auth_and_capture",
            installments: 1,
            statement_descriptor: "Inst Estacao",
            card_token: card_hash,
            card: {
              billing_address: {
                line_1: "1, Rua Principal, Centro",
                zip_code: "69300000",
                city: "Boa Vista",
                state: "RR",
                country: "BR"
              }
            }
          }
        }
      ];
    } else if (payment_method === "pix") {
      transactionData.payments = [
        {
          payment_method: "pix",
          pix: {
            expires_in: 86400
            // 24 horas
          }
        }
      ];
    } else if (payment_method === "boleto") {
      transactionData.payments = [
        {
          payment_method: "boleto",
          boleto: {
            instructions: "Sr. Caixa, favor n\xE3o aceitar pagamento ap\xF3s o vencimento",
            due_at: new Date(Date.now() + 3 * 24 * 60 * 60 * 1e3).toISOString()
          }
        }
      ];
    }
    console.log("Enviando requisi\xE7\xE3o para Pagar.me API V5...");
    console.log("Transaction Data:", JSON.stringify(transactionData, null, 2));
    const authHeader = `Basic ${Buffer.from(`${accessToken}:`).toString("base64")}`;
    const apiResponse = await fetch("https://api.pagar.me/core/v5/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": authHeader,
        "X-Pagarme-Account-Id": accountId
      },
      body: JSON.stringify(transactionData)
    });
    const transaction = await apiResponse.json();
    console.log("Resposta completa da API:", JSON.stringify(transaction, null, 2));
    console.log("Status HTTP:", apiResponse.status);
    if (!apiResponse.ok) {
      console.error("Erro da API Pagar.me - Status:", apiResponse.status);
      console.error("Erro da API Pagar.me - Body:", JSON.stringify(transaction, null, 2));
      let errorMessage = "Erro ao processar pagamento";
      if (transaction.errors && Array.isArray(transaction.errors) && transaction.errors.length > 0) {
        errorMessage = transaction.errors.map((e) => `${e.parameter_name}: ${e.message}`).join(", ");
      } else if (transaction.message) {
        errorMessage = transaction.message;
      }
      throw new Error(errorMessage);
    }
    const response = {
      transactionId: transaction.id,
      status: transaction.status,
      paymentMethod: payment_method
    };
    if (payment_method === "pix") {
      const charge = transaction.charges?.[0];
      const lastTransaction = charge?.last_transaction;
      if (lastTransaction?.qr_code) {
        response.pixQrCode = lastTransaction.qr_code;
        response.pixQrCodeUrl = lastTransaction.qr_code_url;
      }
    } else if (payment_method === "boleto") {
      const charge = transaction.charges?.[0];
      const lastTransaction = charge?.last_transaction;
      if (lastTransaction?.pdf) {
        response.boletoUrl = lastTransaction.pdf;
        response.boletoBarcode = lastTransaction.line;
      }
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(response)
    };
  } catch (error) {
    console.error("Erro ao processar pagamento Pagar.me:", error);
    console.error("Stack:", error.stack);
    const errorMessage = error.message || "Erro desconhecido";
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        message: "Erro ao processar pagamento",
        error: errorMessage
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
