var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/process-pagarme-payment.ts
var process_pagarme_payment_exports = {};
__export(process_pagarme_payment_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(process_pagarme_payment_exports);
var secretKey = process.env.PAGARME_SECRET_KEY || process.env.PAGARME_ACCESS_TOKEN || "";
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ message: "Method Not Allowed" })
    };
  }
  try {
    if (!secretKey) {
      console.error("Secret Key n\xE3o configurada");
      throw new Error("Credenciais do Pagar.me n\xE3o configuradas");
    }
    const body = JSON.parse(event.body || "{}");
    const {
      amount,
      donor_name,
      donor_email,
      donor_phone,
      donor_cpf,
      payment_method,
      card,
      installments
    } = body;
    console.log("Processando pagamento V5:", { amount, payment_method, donor_email });
    if (!amount || amount <= 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: "Valor inv\xE1lido" })
      };
    }
    if (!donor_email) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: "Email \xE9 obrigat\xF3rio" })
      };
    }
    const amountInCents = Math.round(amount * 100);
    const phoneClean = donor_phone?.replace(/\D/g, "") || "";
    const areaCode = phoneClean.slice(0, 2) || "11";
    const phoneNumber = phoneClean.slice(2) || "999999999";
    const customerCpf = donor_cpf?.replace(/\D/g, "") || "00000000000";
    const orderData = {
      customer: {
        name: donor_name || "Doador An\xF4nimo",
        email: donor_email,
        type: "individual",
        document: customerCpf,
        document_type: "cpf",
        phones: {
          mobile_phone: {
            country_code: "55",
            area_code: areaCode,
            number: phoneNumber
          }
        }
      },
      items: [
        {
          amount: amountInCents,
          description: "Doa\xE7\xE3o - Instituto Esta\xE7\xE3o",
          quantity: 1,
          code: "DOACAO"
        }
      ]
    };
    if (payment_method === "credit_card") {
      if (!card || !card.number) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ message: "Dados do cart\xE3o n\xE3o fornecidos" })
        };
      }
      orderData.payments = [
        {
          payment_method: "credit_card",
          credit_card: {
            installments: installments || 1,
            statement_descriptor: "INST ESTACAO",
            card: {
              number: card.number.toString().replace(/\s/g, ""),
              holder_name: card.holder_name.toUpperCase(),
              exp_month: parseInt(card.exp_month),
              exp_year: parseInt(card.exp_year),
              cvv: card.cvv.toString(),
              billing_address: {
                line_1: "1, Rua Principal, Centro",
                zip_code: "69300000",
                city: "Boa Vista",
                state: "RR",
                country: "BR"
              }
            }
          }
        }
      ];
    } else if (payment_method === "pix") {
      orderData.payments = [
        {
          payment_method: "pix",
          pix: {
            expires_in: 86400
            // 24 horas em segundos
          }
        }
      ];
    } else if (payment_method === "boleto") {
      const dueDate = /* @__PURE__ */ new Date();
      dueDate.setDate(dueDate.getDate() + 3);
      orderData.payments = [
        {
          payment_method: "boleto",
          boleto: {
            instructions: "Sr. Caixa, favor n\xE3o aceitar pagamento ap\xF3s o vencimento",
            due_at: dueDate.toISOString()
          }
        }
      ];
    }
    console.log("Enviando requisi\xE7\xE3o para Pagar.me API V5...");
    console.log("Order data:", JSON.stringify(orderData, null, 2));
    const authString = Buffer.from(`${secretKey}:`).toString("base64");
    const apiUrl = "https://api.pagar.me/core/v5/orders";
    const apiResponse = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Basic ${authString}`
      },
      body: JSON.stringify(orderData)
    });
    const order = await apiResponse.json();
    console.log("PAGARME V5 RESPONSE:", JSON.stringify(order, null, 2));
    console.log("Status HTTP:", apiResponse.status);
    if (!apiResponse.ok) {
      console.error("Erro da API Pagar.me V5 - Status:", apiResponse.status);
      console.error("Erro da API Pagar.me V5 - Body:", JSON.stringify(order, null, 2));
      let userMessage = "Erro ao processar pagamento. Por favor, tente novamente.";
      if (order.errors && Array.isArray(order.errors)) {
        const errorMessages = order.errors.map((e) => e.message || e.parameter_name).join(", ");
        userMessage = errorMessages || userMessage;
      } else if (order.message) {
        userMessage = order.message;
      }
      return {
        statusCode: 402,
        headers,
        body: JSON.stringify({
          message: userMessage,
          status: order?.status,
          raw_error: order.errors || order.message
        })
      };
    }
    const charge = order.charges?.[0];
    const lastTransaction = charge?.last_transaction;
    console.log("Charge:", JSON.stringify(charge, null, 2));
    console.log("Last Transaction:", JSON.stringify(lastTransaction, null, 2));
    const response = {
      transactionId: order.id || `ORDER-${Date.now()}`,
      status: order.status,
      paymentMethod: payment_method
    };
    if (order.status === "paid") {
      response.status = "paid";
    } else if (order.status === "pending") {
      response.status = "pending";
    } else if (order.status === "failed") {
      response.status = "failed";
      response.message = lastTransaction?.gateway_response?.message || lastTransaction?.acquirer_message || charge?.last_transaction?.gateway_response?.errors?.[0]?.message || "Transa\xE7\xE3o recusada";
    }
    const apiErrorMessage = lastTransaction?.gateway_response?.message || lastTransaction?.acquirer_message || charge?.last_transaction?.gateway_response?.errors?.[0]?.message || lastTransaction?.gateway_response?.errors?.[0]?.message || null;
    console.log("API Error Message:", apiErrorMessage);
    if (payment_method === "pix") {
      if (order.status === "failed" || charge?.status === "failed") {
        response.status = "failed";
        response.message = apiErrorMessage || "PIX n\xE3o habilitado ou erro na configura\xE7\xE3o da conta Pagar.me";
        response.debug = {
          orderStatus: order.status,
          chargeStatus: charge?.status,
          apiError: apiErrorMessage
        };
      } else {
        const pixQrCode = lastTransaction?.qr_code || charge?.last_transaction?.qr_code || order.charges?.[0]?.last_transaction?.qr_code;
        const pixQrCodeUrl = lastTransaction?.qr_code_url || charge?.last_transaction?.qr_code_url || order.charges?.[0]?.last_transaction?.qr_code_url;
        console.log("PIX QR Code encontrado:", pixQrCode ? "SIM" : "N\xC3O");
        console.log("PIX QR Code URL encontrado:", pixQrCodeUrl ? "SIM" : "N\xC3O");
        if (pixQrCode) {
          response.pixQrCode = pixQrCode;
          response.pixQrCodeUrl = pixQrCodeUrl || `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(pixQrCode)}`;
          response.status = "pending";
        } else {
          console.error("PIX QR Code n\xE3o encontrado na resposta");
          console.error("Order completo:", JSON.stringify(order, null, 2));
          response.debug = {
            orderStatus: order.status,
            chargeStatus: charge?.status,
            hasCharges: !!order.charges,
            chargesLength: order.charges?.length,
            hasLastTransaction: !!lastTransaction
          };
        }
      }
    } else if (payment_method === "boleto") {
      if (order.status === "failed" || charge?.status === "failed") {
        response.status = "failed";
        response.message = apiErrorMessage || "Boleto n\xE3o habilitado ou erro na configura\xE7\xE3o da conta Pagar.me";
        response.debug = {
          orderStatus: order.status,
          chargeStatus: charge?.status,
          apiError: apiErrorMessage
        };
      } else {
        const boletoUrl = lastTransaction?.pdf || lastTransaction?.url || charge?.last_transaction?.pdf || charge?.last_transaction?.url;
        const boletoBarcode = lastTransaction?.line || lastTransaction?.barcode || charge?.last_transaction?.line || charge?.last_transaction?.barcode;
        if (boletoUrl) {
          response.boletoUrl = boletoUrl;
          response.boletoBarcode = boletoBarcode || "";
          response.status = "waiting_payment";
        } else {
          console.error("Boleto URL n\xE3o encontrado na resposta");
          response.debug = {
            orderStatus: order.status,
            chargeStatus: charge?.status
          };
        }
      }
    } else if (payment_method === "credit_card") {
      if (charge?.status === "paid") {
        response.status = "paid";
      } else if (charge?.status === "pending") {
        response.status = "authorized";
      } else if (charge?.status === "failed" || order.status === "failed") {
        response.status = "failed";
        response.message = lastTransaction?.acquirer_message || lastTransaction?.gateway_response?.message || "Pagamento recusado pela operadora";
      }
    }
    console.log("Response final:", JSON.stringify(response, null, 2));
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(response)
    };
  } catch (error) {
    console.error("Erro ao processar pagamento Pagar.me V5:", error);
    console.error("Stack:", error.stack);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        message: "Erro ao processar pagamento",
        error: error.message || "Erro desconhecido"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
